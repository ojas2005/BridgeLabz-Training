class Program
{
    static void Main()
    {
        Menu.ShowMainMenu();
    }
}
