public interface IManager
{
    void Display();
}
