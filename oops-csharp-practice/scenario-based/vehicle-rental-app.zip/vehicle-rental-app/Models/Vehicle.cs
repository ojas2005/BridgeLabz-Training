namespace VehicleRentalApp.Models
{
    public abstract class Vehicle : IRentable
    {
        // protected fields for encapsulation
        protected string vehicleId;
        protected string vehicleName;
        protected decimal dailyRate;
        protected bool isAvailable;

        public Vehicle(string id, string name, decimal rate)
        {
            vehicleId = id;
            vehicleName = name;
            dailyRate = rate;
            isAvailable = true;
        }

        public string VehicleId
        {
            get
            {
                return vehicleId;
            }
            set
            {
                vehicleId = value;
            }
        }

        public string VehicleName
        {
            get
            {
                return vehicleName;
            }
            set
            {
                vehicleName = value;
            }
        }

        public decimal DailyRate
        {
            get
            {
                return dailyRate;
            }
            set
            {
                dailyRate = value;
            }
        }

        public bool IsAvailable
        {
            get
            {
                return isAvailable;
            }
            set
            {
                isAvailable = value;
            }
        }

        // abstract method for polymorphism
        public abstract decimal CalculateRent(int days);

        public virtual void DisplayInfo()
        {
            Console.WriteLine($"Vehicle ID: {vehicleId}");
            Console.WriteLine($"Vehicle Name: {vehicleName}");
            Console.WriteLine($"Daily Rate: ${dailyRate}");
            Console.WriteLine($"Available: {isAvailable}");
        }
    }
}
