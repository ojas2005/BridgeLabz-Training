namespace VehicleRentalApp.Models
{
    public interface IRentable
    {
        decimal CalculateRent(int days);
    }
}
