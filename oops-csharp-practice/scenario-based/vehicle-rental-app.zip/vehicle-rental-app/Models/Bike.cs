namespace VehicleRentalApp.Models
{
    public class Bike : Vehicle
    {
        private int engineCC;

        public Bike(string id, string name, decimal rate, int cc) : base(id, name, rate)
        {
            engineCC = cc;
        }

        public int EngineCC
        {
            get
            {
                return engineCC;
            }
            set
            {
                engineCC = value;
            }
        }

        // bike has lower discount on days
        public override decimal CalculateRent(int days)
        {
            decimal totalRent = dailyRate * days;
            
            if (days > 5)
            {
                totalRent = totalRent * 0.9m; // 10% discount for more than 5 days
            }
            
            return totalRent;
        }

        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Engine CC: {engineCC}cc");
        }
    }
}
