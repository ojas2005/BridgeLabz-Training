namespace VehicleRentalApp.Models
{
    public class Truck : Vehicle
    {
        private decimal cargoCapacityTons;

        public Truck(string id, string name, decimal rate, decimal cargo) : base(id, name, rate)
        {
            cargoCapacityTons = cargo;
        }

        public decimal CargoCapacity
        {
            get
            {
                return cargoCapacityTons;
            }
            set
            {
                cargoCapacityTons = value;
            }
        }

        // trucks have high discount due to longer rentals
        public override decimal CalculateRent(int days)
        {
            decimal totalRent = dailyRate * days;
            
            if (days > 2)
            {
                totalRent = totalRent * 0.8m; // 20% discount for more than 2 days
            }
            
            return totalRent;
        }

        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Cargo Capacity: {cargoCapacityTons} tons");
        }
    }
}
