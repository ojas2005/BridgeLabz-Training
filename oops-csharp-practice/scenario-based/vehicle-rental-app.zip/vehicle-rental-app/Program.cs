using VehicleRentalApp.Models;

class Program
{
    static void Main()
    {
        Console.WriteLine("===== Vehicle Rental Application =====\n");

        // create customers
        Customer customer1 = new Customer("C001", "John Doe", "555-1234", "john@email.com");
        Customer customer2 = new Customer("C002", "Jane Smith", "555-5678", "jane@email.com");

        // create vehicles
        Bike bike = new Bike("B001", "Harley Davidson", 50m, 1200);
        Car car = new Car("CAR001", "Honda Civic", 100m, 5, "Petrol");
        Truck truck = new Truck("T001", "Volvo FH16", 200m, 25);

        // display customer and vehicle info
        Console.WriteLine("--- Customer 1 Information ---");
        customer1.DisplayInfo();
        
        Console.WriteLine("\n--- Customer 2 Information ---");
        customer2.DisplayInfo();

        Console.WriteLine("\n--- Vehicle Information ---");
        Console.WriteLine("\nBike Details:");
        bike.DisplayInfo();

        Console.WriteLine("\nCar Details:");
        car.DisplayInfo();

        Console.WriteLine("\nTruck Details:");
        truck.DisplayInfo();

        // calculate rental costs using polymorphism
        Console.WriteLine("\n--- Rental Calculations ---");
        int rentalDays = 6;

        decimal bikeRent = bike.CalculateRent(rentalDays);
        decimal carRent = car.CalculateRent(rentalDays);
        decimal truckRent = truck.CalculateRent(rentalDays);

        Console.WriteLine($"\nRental for {rentalDays} days:");
        Console.WriteLine($"Bike Rental Cost: ${bikeRent}");
        Console.WriteLine($"Car Rental Cost: ${carRent}");
        Console.WriteLine($"Truck Rental Cost: ${truckRent}");

        // test with different rental period
        int shortRental = 2;
        Console.WriteLine($"\n--- Short Rental ({shortRental} days) ---");
        Console.WriteLine($"Bike: ${bike.CalculateRent(shortRental)}");
        Console.WriteLine($"Car: ${car.CalculateRent(shortRental)}");
        Console.WriteLine($"Truck: ${truck.CalculateRent(shortRental)}");
    }
}
